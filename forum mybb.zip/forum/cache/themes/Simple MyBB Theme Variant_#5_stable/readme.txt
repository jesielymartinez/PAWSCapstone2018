---About The Theme---
A very simple light yet effect clean on the eyes MyBB theme, this is a good start to make modifications on. You can use this theme as you please but leave all credits to MyBB and myself in the footer. This theme uses images from the default image folder, keep the original MyBB images. Feel free to edit this theme as you wish but do not remove the MyBB Credit or Credits to MyBB Hub.

---Uploading The Theme---
This theme uses the default MyBB images, simply upload in the Admin CP and activate.
The theme should work okay - advise to force classic_postbit on the forums.

---Credits---
An official release from the team at MyBB Hub - http://mybbhub.com/
The official Github project - https://github.com/Its-Nasyr/MyBB-SimpleTheme-Variant

---Contact Me---
Message me on the MyBB Community - https://community.mybb.com/user-77508.html
Send me a Tweet on Twitter - https://twitter.com/Admixing
Add me on Discord: Nasyr#1749

---Warning---
Do not removing any credits from the footer of this theme.