<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

// Help Section 1
$l['s1_name'] = "Mantenimiento para usuarios";
$l['s1_desc'] = "Instrucciones básicas para el mantenimiento de una cuenta en el foro.";

// Help Section 2
$l['s2_name'] = "Participación";
$l['s2_desc'] = "Participar, responder, y otras instrucciones básicas del uso del foro.";
