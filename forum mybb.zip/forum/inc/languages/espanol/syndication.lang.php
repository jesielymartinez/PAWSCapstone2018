<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['all_forums'] = "Todos los foros";
$l['forum'] = "Foro:";
$l['posted_by'] = "Publicado por:";
$l['on'] = "en";
$l['portal'] = "Portal";

