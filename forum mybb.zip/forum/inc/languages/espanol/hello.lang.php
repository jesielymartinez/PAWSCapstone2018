<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 *
 * Translator: Anio_pke
 */

$l['hello'] = '�Hola Mundo!';
$l['hello_add'] = 'Agregar';
$l['hello_add_message'] = 'Agregar mensaje';
$l['hello_empty'] = 'No se han encontrado mensajes.';
$l['hello_message_empty'] = 'El mensaje no puede estar vac�o.';
$l['hello_done'] = 'Se ha agregado un nuevo mensaje correctamente.';