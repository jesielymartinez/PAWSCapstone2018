<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Nombre del documento";
 * $l['d{hid}_desc'] = "Descripción del documento";
 * $l['d{hid}_document'] = "Texto del documento";
 */
