<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

/*
 * Custom Help Section Translation Format
 *
 * // Help Section {sid}
 * $l['s{sid}_name'] = "Nombre de la sección";
 * $l['s{sid}_desc'] = "Descripción de la sección";
 */
