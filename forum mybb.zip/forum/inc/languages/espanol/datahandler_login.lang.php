<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['logindata_invalidpwordusername'] = "Has introducido una combinación de usuario/contraseña inválida. <br /><br />Si has olvidado tu contraseña por favor <a href=\"member.php?action=lostpw\">pide una nueva</a>.";
$l['logindata_invalidpwordusernameemail'] = "Has introducido una combinación de email/contraseña inválida. <br /><br />Si has olvidado tu contraseña por favor <a href=\"member.php?action=lostpw\">pide una nueva</a>.";
$l['logindata_invalidpwordusernamecombo'] = "Has introducido una combinación de usuario/contraseña o email/contraseña inválida. <br /><br />Si has olvidado tu contraseña por favor <a href=\"member.php?action=lostpw\">pide una nueva</a>.";

$l['logindata_regimageinvalid'] = "El código de imagen de verificación que has introducido es incorrecto. Por favor, introduce el código exactamente como aparece en la imagen.";
$l['logindata_regimagerequired'] = "Por favor, introduce el código de la imagen de verificación para iniciar sesión. Por favor, introduce el código exactamente como aparece en la imagen.";
