<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['home'] = "Portada";

$l['dashboard'] = "Principal";
$l['preferences'] = "Preferencias";
$l['mybb_credits'] = "Créditos MyBB";

$l['add_new_forum'] = "Añadir un foro";
$l['search_for_users'] = "Buscar usuarios";
$l['themes'] = "Estilos";
$l['templates'] = "Plantillas";
$l['plugins'] = "Plugins";
$l['database_backups'] = "Copias de seguridad";
$l['quick_access'] = "Acceso rápido";
$l['online_admins'] = "Administradores en línea";
$l['ipaddress'] = "Dirección IP:";
$l['mybb_documentation'] = "Documentación MyBB";

