<?php
/* by Tomasz 'Devilshakerz' Mlynski [devilshakerz.com]; Copyright (C) 2015-2017
 released under Creative Commons BY-NC-SA 4.0 license: https://creativecommons.org/licenses/by-nc-sa/4.0/ */

$l['dvz_sc_avatars_https_only'] = '<br /><b>The avatar URL has to begin with <i>https://</i>.</b>';
