<?php

//Admin CP Group Permissions
$l['profilmuzigiek_setting_music_perm'] = "Profile Music Permissions";
$l['profilmuzigiek_setting_can_add_music'] = "Can add profile music?";

$l['profilmuzigiek_setting_user_title'] = "Profile Music Settings";
$l['profilmuzigiek_setting_music'] = "User profile music link:";
$l['profilmuzigiek_setting_user_can_add'] = "User can add profile music?";

?>