<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['nav_announcements'] = "Anuncios del foro";
$l['announcements'] = "Anuncios";
$l['forum_announcement'] = "Anuncios del foro: {1}";
$l['error_invalidannouncement'] = "El anuncio especificado es inválido.";

$l['announcement_edit'] = "Editar este anuncio";
$l['announcement_qdelete'] = "Eliminar este anuncio";
$l['announcement_quickdelete_confirm'] = "¿Estás seguro de querer eliminar este anuncio?";

