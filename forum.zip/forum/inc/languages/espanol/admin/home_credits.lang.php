<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['mybb_credits'] = "Créditos MyBB";
$l['mybb_credits_description'] = "Esta gente ha contribuido con su tiempo y esfuerzo para crear MyBB.";
$l['about_the_team'] = "Sobre el equipo";
$l['check_for_updates'] = "Comprobar actualizaciones";
$l['error_communication'] = "Ha ocurrido un problema al descargar los últimos créditos. Por favor, inténtalo de nuevo en unos minutos.";
$l['no_credits'] = "No hay créditos almacenados. <a href=\"index.php?module=home-credits&amp;fetch_new=1\">Comprobar actualizaciones</a>.";
$l['success_credits_updated'] = 'La caché de créditos de MyBB se ha actualizado correctamente.';
