<?php
/**
 * MyBB 1.8 Spanish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Translator: Anio_pke
 */

$l['templates_and_style'] = "Estilos y plantillas";

$l['themes'] = "Estilos";
$l['templates'] = "Plantillas";

$l['can_manage_themes'] = "¿Puede configurar estilos?";
$l['can_manage_templates'] = "¿Puede configurar plantillas?";

